var calcular = require('./conversiones');

calcular.realizarPruebas();