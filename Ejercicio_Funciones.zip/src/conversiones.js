const fs = require('fs');

function converCaF(val1){
    val1= val1*1.8;
    return val1+32;
}
function converKmsaMilla(val1){
    return val1*0.62;
}
function converKlaLb(val1){
    return val1*2.20;
}
function converPgaCm(val1){
    return val1*2.54;
}
function converFtaPg(val1){
    return val1*12;
}

//FUNCION PARA REALIZAR LAS PRUEBAS
function realizarPruebas() {
    const resultados = [];
  
    // Prueba 1: De centigrados a farenheit
    const resultadoPrueba1 = converCaF(10);
    resultados.push(`Prueba funcion: converCaF\nGrados Centigrados origen: 10\nGrados Farenheit Convertidos: ${resultadoPrueba1}`);
    resultados.push('-------------------------------------------\n');
    // Prueba 2: De Kilometros a Millas 
    const resultadoPrueba2 = converKmsaMilla(15);
    resultados.push(`Prueba funcion: converKmaMilla\nKilometros: 15\nMillas: ${resultadoPrueba2}`);
    resultados.push('-------------------------------------------\n');
  
    // Prueba 3: De kilogramos a libras
    const resultadoPrueba3 = converKlaLb(8);
    resultados.push(`Prueba funcion: converKlaLb\nKilogramos: 8\nLibras: ${resultadoPrueba3}`);
    resultados.push('-------------------------------------------\n');

    // Prueba 3: De pulgadas a centimetros 
    const resultadoPrueba4 = converPgaCm(18);
    resultados.push(`Prueba funcion: converPgaCm\nPulgadas: 18\nCentimetros: ${resultadoPrueba4}`);
    resultados.push('-------------------------------------------\n');

    // Prueba 3: De kilogramos a libras
    const resultadoPrueba5 = converFtaPg(12);
    resultados.push(`Prueba funcion: converFtaPg\nPies: 12\nPulgadas: ${resultadoPrueba5}`);
    resultados.push('-------------------------------------------\n');

    // Escribir los resultados en el archivo pruebaconversiones.txt
    fs.writeFileSync('pruebaconversiones.txt', resultados.join('\n'));
  }

exports.realizarPruebas = realizarPruebas;
exports.converCaF = converCaF; 
exports.converKmsaMilla = converKmsaMilla;
exports.converKlaLb = converKlaLb;
exports.converPgaCm = converPgaCm;
exports.converFtaPg = converFtaPg;